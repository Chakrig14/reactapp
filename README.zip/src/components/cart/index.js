const Cart = () => {
    return(
        <div>
            <h1>Cart page</h1>
        </div>
    )
}

export default Cart